#include "Sample_LIB.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Sum(int a[SiZE])
{
    a[0] = 9999;
    a[1] = 2222;
    a[2] = 3333;

    //a++ = 2222;
    // for (int i = 0; i < TFL_SIZE; i++)
	// {			
	// 	arr[i].x = (float)(1);
	// 	arr[i].y = (float)(2);
	// 	arr[i].z = (float)(3);
	// }

    int b = 99;
    return b;
}