#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Sample_LIB.h"
#include <stdbool.h>
#include <time.h>

int main()
{
    int a[SiZE];
    int b = Sum(a);
    printf("Adress b is: %x \n", &b);
    for(int i = 0; i < 3; i++)
    {
        printf("Phan tu thu %d la: %d \n", i, a[i]);
        printf("Adress a is: %x \n", a[i]);
    }

    return 0;  
}